<!-- 文本输入框 -->
<template>
<div class="text" style="height: 210px;">
    <div class="emoji">
          <i class="icon iconfont icon-look" @click="showEmoji=!showEmoji"></i>
          <transition name="showbox">
             <ul class="emojiBox" v-show="showEmoji">
                 <li v-for="(item, index) in emojis" :key="index">
                    <!-- <img :src="'./assets/emoji/'+item.file" :data="item.code" @click="content +=item.code"> -->
                    <img :src="'./assets/emoji/'+item.file" :data="item.code" @click="insertEmoji('./assets/emoji/'+item.file)">
                 </li>
             </ul>
          </transition>
    </div>
    <template v-if="visable">
      <Toolbar
          style="border-bottom: 1px solid #ccc"
          :editor="editorRef"
          :defaultConfig="toolbarConfig"
          :mode="mode"
        />
      <Editor
          style="height: 210px; overflow-y: hidden;"
          @keyup.enter="send"
          :mode="mode"
          v-model="valueHtml"
          :defaultConfig="editorConfig"
          @onChange="onChange"
          @onCreated="onCreated"
          @click="showEmoji=false"
      />
    </template>
    <Websocket ref="websocket" v-on:listenToChildEvent="receivedChildMsg"></Websocket>
    <div class="send" @click="send">
    	<span>发送(ent)</span>
    </div>
    <transition name="appear">
	    <div class="warn" v-show="warn">
	    	<div class="description">不能发送空白信息</div>
	    </div>
	</transition>
</div>
</template>

<script>
import { mapGetters, mapState } from 'vuex'

import '@wangeditor/editor/dist/css/style.css' // 引入 css
import { onBeforeUnmount, ref, shallowRef, onMounted } from 'vue'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import { IEditorConfig, IToolbarConfig } from "@wangeditor/editor";
import { DomEditor } from '@wangeditor/editor'

import Websocket from '@/components/websocket/websocket.vue'

export default {
    components: { Editor, Toolbar, Websocket },
    setup() {
        // 编辑器实例，必须用 shallowRef
        const editorRef = shallowRef()
    
        // 内容 HTML
        const valueHtml = ref('')
    
        // 模拟 ajax 异步获取内容
        onMounted(() => {
            // setTimeout(() => {
            //     valueHtml.value = '<p>模拟 Ajax 异步设置内容</p>'
            // }, 1500)
        })
 
        const toolbarConfig = {
          //隐藏的toolbarKey,默认为空
          excludeKeys: [          
            'blockquote', 'header1', 'header2', 'header3', '|', 'bold', 'underline', 'italic', 'through', 'color', 'bgColor', 'clearStyle',
            '|', 'bulletedList', 'numberedList', 'todo', 'justifyLeft', 'justifyRight', 'justifyCenter', '|', 'insertLink', 'group-image', 'insertVideo',
            'insertTable', 'codeBlock', '|', 'undo', 'redo', '|', 'fullScreen'
          ]
        }

        const editorConfig = { 
            placeholder: '',
            // autoFocus: false,
            scroll: false,
            maxLength: 1000,
            // 其他配置...
            MENU_CONF: {
              uploadImage: {
                // 小于该值就插入 base64 格式（而不上传），默认为 0
                base64LimitSize: 10 * 1024 // 5kb
              }
            }
        }
 
        // 组件销毁时，也及时销毁编辑器
        onBeforeUnmount(() => {
          const editor = editorRef.value;
          if (editor == null) return;

          editor.destroy();
        });
 
        // const handleCreated = (editor) => {
        //     editorRef.value = editor // 记录 editor 实例，重要
        // }

        const disable = () => {
          const editor = editorRef.value;
          if (editor == null) return;
          editor.disable()
        };

        const customPaste = (editor,event,callback) => {
          console.log('clipboardEvent 粘贴事件对象', event);
          // const html = event.clipboardData.getData('text/html')// 获取粘贴的 html// const text = event.clipboardData.getData('text/plain')// 获取粘贴的纯文本
          // const rtf = event.clipboardData.getData('text/rtf')// 获取 rtf 数据(如从 word wsp 复制粘贴
          //自定义插入内容
          // editor.insertText('xxx')
          // 返回 false ，阻止默认粘贴行为
          event.preventDefault()
          callback(false);//返回值(注意，vue 事件的返回值，不能用return)
          //返回 true ，继续默认的粘贴行为
          //  callback(true)
        }
 
        return {
            editorRef,
            valueHtml,
            mode: 'simple', // 或 simple、default
            toolbarConfig,
            editorConfig,
            // handleCreated,
            disable,
            customPaste
        };
    },
    data () {
        return {
            edito: null,
            content: '',
            reply: '未找到',  
            frequency: 0,
            warn: false,
            showEmoji: false,
            visable: true,
            enterKey: false,
            initValueHtml: '<p><br></p>',
        }
    },
    computed: {
        ...mapState([   
            'selectId',
            'emojis'
        ]),
        ...mapGetters([
            'selectedChat',
            'getLoginUser'
        ])
    },
    methods: {
        // 点击发送按钮发送信息
        send () {
          let that = this
            that.showEmoji=false;
            if(that.valueHtml.length <= 1 || that.valueHtml.replaceAll(that.initValueHtml, '').length <=1 ){
                that.warn = true
                setTimeout(() => {
                    that.warn = false;
                }, 1000)
            } else {
                  let domValue = that.strToDom(that.valueHtml)
                  that.valueHtml = domValue.outerHTML
                  var msg = {
                      content: that.valueHtml,
                  }
                  that.$store.dispatch('sendMessage', msg)
                  that.sendMsgByWebSocket()
                  that.valueHtml = that.initValueHtml
              }

              // 销毁重新渲染组件
              that.visable= false
              that.$nextTick(()=>{
                that.visable = true
              })
        },
        async insertEmoji(emoji) {
            let pEl = this.strToDom(this.valueHtml)

            // 查询文档中所有的 <br> 标签
            const brTags = pEl.querySelectorAll('br');
            
            // 循环遍历并移除所有找到的 <br> 标签
            brTags.forEach(brTag => {
                brTag.remove();
            });

            let imgBase64 = await this.urlToBase64(`http://localhost:8080/${emoji}`)
            .then(function(result) {
             return result
          })

            let imgEl = document.createElement('img')
            imgEl.src=imgBase64
            pEl.append(imgEl)

            let vaule = pEl.outerHTML
            this.valueHtml = vaule
            
        },

        strToDom(htmlString) {
            if (htmlString) {
                // 创建一个新的DOMParser实例
                var parser = new DOMParser();
                // 使用DOMParser的parseFromString方法来转换字符串到DOM
                var doc = parser.parseFromString(htmlString, "text/html");
                // 获取转换后的DOM对象
                var dom = doc.body.firstChild;
                // dom.classList.add('lastmsg')
                // dom.style.margin = '10px 0px 0px';
                return dom
            }
            return null 
        },

        onCreated(editor) {
            this.editor = Object.seal(editor) // 【注意】一定要用 Object.seal() 否则会报错
        },

        onChange(editor) {
            const content = editor.getHtml()
            if (this.enterKey) {
                if (content != this.initValueHtml && content.replaceAll(this.initValueHtml,'').length > 0 && content.includes(this.initValueHtml)) {
                    console.log('用户按下了回车键！')
                    //  去掉后面的换行标签
                    let dom = this.strToDom(this.valueHtml.replaceAll(this.initValueHtml, ''))
                    if (dom) {
                        this.valueHtml = dom.outerHTML
                        // 在这里处理回车事件
                        this.send()
                    }
                } else if (content != this.initValueHtml && content.replaceAll(this.initValueHtml,'').length == 0) {
                    this.visable = false
                    this.warn = true
                    this.valueHtml = this.initValueHtml
                    setTimeout(() => {
                        this.warn = false;
                    }, 1000)
                }
            }
        },

        urlToBase64(url) {
            return new Promise((resolve,reject)=>{
              // 创建一个 XMLHttpRequest 对象
              const xhr = new XMLHttpRequest();
              xhr.open('GET', url);
              //1 设置响应类型为 blob，以获取图像数据
              xhr.responseType ='blob';
              // 请求成功时的处理函数
              xhr.onload=()=>{
                //1 创建一个 FileReader 对象，用于读取 blob 数据
                const reader =new FileReader();
                // 读取完成时的处理函数
                reader.onloadend=()=>{
                // 将读取到的数据(Base64 字符串)传递给 resolve 函数
                  resolve(reader.result);
                };
                // 读取失败时的处理函数
                reader.onerror=reject;
                // 将 blob 数据读取为 Base64 字符串
                reader.readAsDataURL(xhr.response);
              };
              // 请求失败时的处理函数
              xhr.onerror =reject;
              // 发送求情
              xhr.send();
            });
        },
        sendMsgByWebSocket() {
          let sendParams = {
              sid: this.getLoginUser.id,
              type: 1,
              from: this.getLoginUser.id,
              to: this.selectId,
              msg: this.valueHtml,
              sendTime: new Date(),
          }
          console.log('发送消息', sendParams)
          //发送信息
          this.$refs.websocket.sendMessage(JSON.stringify(sendParams));
        },

        receivedChildMsg(msg) {
          let that = this
          let msgJson = JSON.parse(msg)
          that.$store.dispatch('sendMessageToMe', {content: msgJson.msg, id: msgJson.sid})
        }
    },
    mounted() {
        // let that = this
        // let userToId = that.selectedChat.id
        // that.useWebSocket = that.useWebSocket(`ws://localhost:8089/websocket/${that.getLoginUser.id}`)
        // that.useWebSocket.addEventListener('message', (event) => {
        //   console.log('收到消息:', event.data);
        //   that.$store.dispatch('sendMessageToMe', {content: event.data, id: userToId})
          
        // }, false)
    },
    watch: {
        // 在选择其它对话的时候 聚焦输入框
        selectId() {
          setTimeout(() => {
            
          }, 0)
        },
        // 当输入框中的值为空时 弹出提示  并在一秒后消失
        content() {
            if(this.content === ''){
                if( this.frequency === 0){
                  this.warn = true;
                  this.frequency++
                  setTimeout(() => {
                    this.warn = false;
                  }, 1000)
                }
            }
        }
    }
}
</script>

<style lang="stylus" scoped>
.w-e-text-container{
    height: 110px !important; /*!important是重点，因为原div是行内样式设置的高度300px*/
}

.text
    position: relative
    height: 150px
    background: #fff
    .emoji
        position: relative
        width: 100%
        height: 40px
        line-height: 40px
        font-size: 12px
        padding: 0 30px
        box-sizing: border-box
        color: #7c7c7c
        .icon-look
            cursor: pointer
            &:hover
                color: #1aad19
        .emojiBox
            li
              list-style-type: none 
              padding-inline-start: 0px
            img
              padding: 5px
            position: absolute
            display: flex
            flex-wrap: wrap
            top: -325px
            left: -100px
            width: 310px
            height: 300px
            padding: 5px
            background-color: #fff
            border: 1px solid #d1d1d1
            border-radius: 2px
            box-shadow:0 1px 2px 1px #d1d1d1
            &.showbox-enter-active, &.showbox-leave-active
                transition: all .5s
            &.showbox-enter,&.showbox-leave-active
                opacity: 0
    textarea
        box-sizing: border-box
        padding: 0 30px
        height: 110px
        width: 100%
        border: none
        outline: none
        font-family: "Micrsofot Yahei"
        resize: none
    .send
        position: absolute
        bottom: -32px
        right: 30px
        width: 75px
        height: 30px
        line-height: 28px
        box-sizing: border-box
        text-align: center
        border: 1px solid #e5e5e5
        border-radius: 3px
        background: #f5f5f5
        font-size: 14px
        color: #7c7c7c
        &:hover
            background: rgb(18,150,17)
            color: #fff
    .warn
         position: absolute
         bottom: 50px
         right: 10px
         width: 110px
         height: 30px
         line-height: 30px
         font-size: 12px
         text-align: center
         border: 1px solid #bdbdbd
         border-radius: 4px
         box-shadow:0 1px 5px 1px #bdbdbd
         &.appear-enter-active, &.appear-leave-active
            transition: all 1s
         &.appear-enter,&.appear-leave-active
            opacity: 0
         &:before
            content: " "
            position: absolute
            top: 100%
            right: 20px
            border: 7px solid transparent
            border-top-color: #fff
            filter:drop-shadow(1px 3px 2px #bdbdbd)
</style>
