<template>
	<div class="content">
		<div class="msglist">
			<search></search>
			<chatlist></chatlist>
		</div>
		<div class="chatbox">
			<message></message>
			<v-text></v-text>
		</div>
	</div>
</template>

<script>
import search from '../../components/search/search.vue'
import chatlist from '../../components/chatlist/chatlist.vue'
import message from '../../components/message/message.vue'
import vText from '../../components/text/text.vue'
export default {
   components: {
   	 search,
   	 chatlist,
   	 message,
   	 vText
   }
}
</script>

<style lang="stylus" scoped>
.content
  display: flex
  width: 800px
  height: auto
  .msglist
    width: 250px
    background: rgb(230,230,230)
  .chatbox
    flex: 1
</style>
