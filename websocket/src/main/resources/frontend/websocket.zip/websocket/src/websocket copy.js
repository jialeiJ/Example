// websocket.js

export const useWebSocket = (url) => {
  // 创建WebSocket实例
  const ws = new WebSocket(url);

  const init = () => {
      ws.addEventListener('open', handleOpen, false);
      ws.addEventListener('close', handleClose, false)
      ws.addEventListener('error', handleError, false)
      // ws.addEventListener('message', handleMessage, false)
  }

  // 监听WebSocket的打开事件
  function handleOpen(event) {
      console.log('WebSocket open', event);
  }
  // 监听WebSocket的关闭事件
  function handleClose(event) {
      console.log('WebSocket close', event);
      //3秒后再次 请求连接webSocket
      setTimeout(reconnectWebSocket,3000);
  }
  // 监听WebSocket的错误事件
  function handleError(event) {
      console.log('WebSocket error', event);
  }
  // 监听WebSocket的消息事件
  function handleMessage(event) {
    console.log('收到消息:', event.data);
  }

  //重新连接webSocket
  function reconnectWebSocket(){
    console.log("reconnectWebSocket重新连接======");
    init();//重新连接
  }

  init();
  return ws;
}