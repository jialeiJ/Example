const BASE_URL = 'http://localhost:8089/'; // 设置全局 URL
const WEB_SOCKET_URL = 'ws://localhost:8089/websocket/'; // 设置全局 URL

export default{
  BASE_URL,
  WEB_SOCKET_URL
}