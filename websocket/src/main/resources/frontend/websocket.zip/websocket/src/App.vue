<template>
  <div id="app">
    <div class="sidebar">
      <mycard></mycard>
    </div>
    <div class="main">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import mycard from './components/mycard/mycard'
import { mapActions } from 'vuex'
export default {
   components: {
     mycard
   },
   created () {
       this.$store.dispatch('initData')
   }
}
</script>

<style lang="stylus" scoped>
#app
  margin: 0px auto
  padding:0;

  display: flex
  border-radius 20px
  margin: 0px auto
  width: 860px
  height: 700px
  background-color: #fff
  .sidebar
    width: 60px
    background: #2b2c2f
  .main
    flex: 1
    background: #f2f2f2


</style>
