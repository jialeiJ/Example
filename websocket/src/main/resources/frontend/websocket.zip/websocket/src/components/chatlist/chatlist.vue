<!-- 聊天列表 -->
<template>
  <div class="msglist">
    <ul>
        <li v-for="item in searchedChatlist" :key="item" class="sessionlist" :class="{ active: item.id === selectId }" @click="selectSession(item.id)">
            <div class="list-left">
              <img class="avatar"  width="50" height="50" :alt="item.user.name" :src="item.user.img">
            </div>
            <div class="list-right">
                <span class="name">{{item.user.name}}</span>
                <span class="time">{{$moment(item.messages[item.messages.length-1].date).format('YYYY-MM-DD HH:mm:ss')}}</span>
                <!-- <div v-html="formatMessage(print(item.messages))"></div> -->
                <div v-html="formatMessage(item.messages[item.messages.length-1].content)"></div>
                <!-- <div>{{print(item.messages)}}</div> -->
            </div>
        </li>
    </ul>
  </div>
</template>

<script>
import { mapState, mapActions ,mapGetters } from 'vuex'
export default {
    setup() {
        const formatMessage = (msg) => {
          if (msg) {
            return msg.replace('<p>', '<p style="margin-bottom: auto;font-size: 14px;width: 130px;height: 18px;line-height: 15px;color: #999;bottom: 0px;overflow: hidden;white-space:nowrap;text-overflow:ellipsis;">');
          }
          return ''  
        };

        const print = (messages) => {
          let otherMessages = messages.filter(item => {return item.self == false})
          let otherMessageObj = otherMessages[otherMessages.length-1]
          console.log(otherMessageObj)
          if (otherMessageObj) {
            let otherMessageStr = JSON.stringify(otherMessageObj)
            if (otherMessageStr) {
              let otherMessage = JSON.parse(otherMessageStr)
              return otherMessage.content
            }
          }
          return '' 
        };
    
        return {
          formatMessage,
          print
        };
    },
    computed: {
       ...mapState([
            'selectId',
            'searchText'
        ]),
        ...mapGetters([
            'searchedChatlist'
        ]),
    },
    methods: {
      ...mapActions([
             'selectSession',
      ])
    },
}
</script>

<style lang="stylus" scoped>
.msglist
  height: 640px
  overflow-y: auto
  ul
    padding-inline-start: 0px
  .sessionlist
    display: flex
    padding: 12px
    transition: background-color .1s
    font-size: 0
    &:hover 
        background-color: rgb(220,220,220)
    &.active 
        background-color: #c4c4c4
    .avatar
        border-radius: 2px
        margin-right: 12px
    .list-right
        position: relative
        flex: 1
        margin-top: 0px
      .name
         display: inline-block
         vertical-align: top
         font-size: 14px
      .time
          float: right
          color: #999 
          font-size: 10px
          vertical-align: top
        ::v-deep .lastmsg
            margin-bottom: auto
            position: absolute
            font-size: 12px
            width: 130px
            height: 24px
            line-height: 15px
            color: #999
            bottom: 0px
            overflow: hidden
            white-space:nowrap
            text-overflow:ellipsis
</style>
