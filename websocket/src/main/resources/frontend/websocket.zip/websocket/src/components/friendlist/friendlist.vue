<!-- 好友列表 -->
<template>
 <div class="friendlist">
 	<ul>
        <li v-for="item in searchedFriendlist" class="frienditem"  :class="{ noborder: !item.initial}">
            <div class="list_title" v-if="item.initial">{{item.initial}}</div>
            <div class="friend-info" :class="{ active: item.id === selectFriendId }" @click="selectFriend(item.id)">
                <img class="avatar"  width="36" height="36" :src="item.img">
                <div class="remark">{{item.remark}}</div>
            </div>
        </li>
    </ul>
 </div>
</template>

<script>
const axios = require('axios');
import { mapState, mapActions ,mapGetters } from 'vuex'
export default {
    computed: {
        ...mapState([
            'selectFriendId',
            'searchText'
        ]),
        ...mapGetters([
            'searchedFriendlist'
        ])
    },
    mounted() {
        this.getFriendList()
    },
    methods: {
        ...mapActions([
             'selectFriend',
        ]),
        getFriendList() {
            let that = this
            axios.post(that.BASE_URL+'getFriendList', {
                firstName: 'Fred',
                lastName: 'Flintstone'
            })
            .then(function (response) {
                that.$store.commit('setFriendListValue', response.data);
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
                    }
    }
}
</script>

<style lang="stylus" scoped>
.friendlist
    height: 640px
    overflow-y: hidden
    ul
        list-style-type none
        padding 0
        margin 0
    .frienditem
        border-top: 1px solid #dadada
        &:first-child,&.noborder
            border-top: none
        .list_title
            box-sizing: border-box
            width: 100%
            font-size: 12px
            padding: 15px 0 3px 12px
            color: #999
        .friend-info
            display: flex
            padding: 12px
            transition: background-color .1s
            font-size: 0
            &:hover 
                background-color: rgb(220,220,220)
            &.active 
                background-color: #c4c4c4
            .avatar
                border-radius: 2px
                margin-right: 12px
            .remark
                font-size: 14px
                line-height: 36px

/*滚动条样式*/
.friendlist:hover {
    overflow-y: auto
}
.friendlist::-webkit-scrollbar-button {
  width: 0px;
  height: 0px;
}


.friendlist::-webkit-scrollbar {/*滚动条整体样式*/
    width: 8px;     /*高宽分别对应横竖滚动条的尺寸*/
    height: 8PX;
    background-color: #E6E6E6;
}

.friendlist::-webkit-scrollbar-thumb {/*滚动条里面小方块*/
    border: none;
    border-radius: 5px;
    -webkit-box-shadow: inset 0 0 8px #CBC8C8;
    background: #8B8B8B;
}
.friendlist::-webkit-scrollbar-track {/*滚动条里面轨道*/
    border: none;
    -webkit-box-shadow: inset 0 0 8px #CBC8C8;
    border-radius: 5px;
    background: #E6E6E6;
}



</style>
