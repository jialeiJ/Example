// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import { createApp } from 'vue';
import { createRouter, createWebHashHistory } from 'vue-router'
import routes from './router/index.js'
import store from './store'
import App from './App'
import moment from 'moment'
import global_ from './constant'


// 定义特性标志
window.__VUE_PROD_DEVTOOLS__ = false;
window.__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = false;

const routers = createRouter({
  history: createWebHashHistory(),
  routes
});


const app = createApp(App);

// 设置全局变量
app.config.globalProperties = global_;
// axios.defaults.baseURL=global_.BASE_URL;


app.config.globalProperties.$moment = moment
//app.config.productionTip = false
app.use(routers)
app.use(store)
app.mount('#app')