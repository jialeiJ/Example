



// import { createRouter, createWebHashHistory } from 'vue-router'
// 共三个页面： 聊天页面，好友页面，个人简历分别对应一下路由
const router = [
    {
      name: 'chat',
      path: '/chat',
      component: () => import('@/page/chat/chat.vue')
    },
    {
      name: 'friend',
      path: '/friend',
      component: () => import('@/page/friend/friend.vue')
    },
    {
      name: 'my',
      path: '/my',
      component: () => import('@/page/resume/resume.vue')
    },
  ]

router.push({ path: '/chat' });
 
export default router