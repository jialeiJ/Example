const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  name: state => state.user.name,
  job: state => state.user.job,
  visitedViews: state => state.tagsView.visitedViews,
  cachedViews: state => state.tagsView.cachedViews,
  // 筛选出含有搜索值的聊天列表
  searchedChatlist(state) {
    const sessions = state.chatlist.filter(sessions => sessions.content.includes(state.searchText))
    // const sessions = 66
    return sessions
  },
  // 筛选出含有搜索值的好友列表
  searchedFriendlist(state) {
    const friends = state.friendlist.filter(friends => friends.remark.includes(state.searchText))
    return friends
  },
  // 通过当前选择是哪个对话匹配相应的对话
  selectedChat(state) {
    const session = state.chatlist.find(session => session.orderid === state.selectId)
    return session
  },
  // 通过当前选择是哪个好友匹配相应的好友
  selectedFriend(state) {
    const friend = state.friendlist.find(friend => friend.id === state.selectFriendId)
    return friend
  },
  messages(state) {
    const session = state.chatlist.find(session => session.id === state.selectId)
    console.log('点击判断', session)
    return session.messages
  }

}
export default getters
